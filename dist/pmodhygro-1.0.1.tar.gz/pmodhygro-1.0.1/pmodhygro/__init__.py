"""
    import class that defines procedure of Pmod HYGRO
    - relative humidity sensor with an integrated temperature sensor
"""
from .pmodhygro import PmodHygro

__all__ = ['pmodhygro']